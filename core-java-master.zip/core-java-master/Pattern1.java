class Pattern1{
	public static void main(String[] args){
		int rows = 4;
		int coloumns = 5;
		
		for(int i = 0;i < rows;i++){
			for(int j=0;j<coloumns;j++){
				System.out.print("*");
			}
			System.out.println();
		}
	}
}